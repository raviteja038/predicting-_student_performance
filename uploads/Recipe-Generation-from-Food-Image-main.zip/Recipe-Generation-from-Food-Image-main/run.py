from Foodimg2Ing import app

if __name__=='__main__':
    app.run(debug=True)